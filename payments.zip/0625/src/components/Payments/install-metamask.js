import React from 'react';

const InstallMetaMask = () => (
  <div className="meta-mask-img">
    <a href="https://metamask.io/">
      <img className="meta-mask-img" src=""  />
    </a>
  </div>
);

export { InstallMetaMask };
module.exports = {
    pending: 'pending',
    cancelled: 'cancelled',
    completed: 'completed' 
};
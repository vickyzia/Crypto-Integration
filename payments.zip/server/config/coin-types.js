module.exports = {
    bitcoin: 'bitcoin',
    ether: 'ether'
};
module.exports = {
    metamask: 1,
    coinpayments: 2 
};